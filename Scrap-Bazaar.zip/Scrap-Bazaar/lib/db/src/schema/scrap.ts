import { createInsertSchema } from "drizzle-zod";
import {
  doublePrecision,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const categoriesTable = pgTable("scrap_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const scrapItemsTable = pgTable("scrap_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  categoryId: integer("category_id")
    .notNull()
    .references(() => categoriesTable.id),
  description: text("description").notNull().default(""),
  pricePerKg: doublePrecision("price_per_kg").notNull(),
  stockKg: doublePrecision("stock_kg").notNull(),
  imageUrl: text("image_url").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertCategorySchema = createInsertSchema(categoriesTable).omit({
  id: true,
});
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categoriesTable.$inferSelect;

export const insertScrapItemSchema = createInsertSchema(scrapItemsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertScrapItem = z.infer<typeof insertScrapItemSchema>;
export type ScrapItem = typeof scrapItemsTable.$inferSelect;