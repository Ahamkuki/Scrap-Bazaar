import { createInsertSchema } from "drizzle-zod";
import {
  doublePrecision,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const scrapSellRequestsTable = pgTable("scrap_sell_requests", {
  id: serial("id").primaryKey(),
  sellerName: text("seller_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  materialName: text("material_name").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  quantityKg: doublePrecision("quantity_kg").notNull(),
  expectedPricePerKg: doublePrecision("expected_price_per_kg").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertScrapSellRequestSchema = createInsertSchema(
  scrapSellRequestsTable,
).omit({
  id: true,
  createdAt: true,
});

export type InsertScrapSellRequest = z.infer<
  typeof insertScrapSellRequestSchema
>;
export type ScrapSellRequest = typeof scrapSellRequestsTable.$inferSelect;