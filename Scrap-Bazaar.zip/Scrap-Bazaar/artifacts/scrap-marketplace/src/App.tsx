import { createContext, type FormEvent, type ReactNode, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  Archive, ArrowRight, BarChart3, Check, ChevronDown, CircleAlert, ClipboardList, Database, Edit3,
  HandCoins, LayoutDashboard, Menu, Minus, PackagePlus, Plus, Recycle, Search, ShoppingBag, ShoppingCart,
  Trash2, Truck, X, Zap,
} from 'lucide-react';
import { Link, Route, Switch, useLocation } from 'wouter';
import {
  getGetDashboardSummaryQueryKey, getGetScrapItemQueryKey, getHealthCheckQueryKey,
  getListCategoriesQueryKey, getListOrdersQueryKey, getListScrapItemsQueryKey, getListSellRequestsQueryKey,
  useCreateCategory, useCreateOrder, useCreateScrapItem, useCreateSellRequest, useDeleteScrapItem,
  useGetDashboardSummary, useGetScrapItem, useHealthCheck, useListCategories,
  useListOrders, useListScrapItems, useListSellRequests, useUpdateScrapItem, useUpdateSellRequest,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import NotFound from '@/pages/not-found';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Router as WouterRouter } from 'wouter';
import './index.css';

type ScrapItemData = {
  id: number; name: string; category: string; description: string; pricePerKg: number; stockKg: number;
  imageUrl: string; status: 'active' | 'sold_out' | 'hidden'; createdAt: string;
};
type CategoryData = { id: number; name: string; itemCount: number };
type LineData = { scrapItemId: number; itemName: string; quantityKg: number; pricePerKg: number; lineTotal: number };
type OrderData = { id: number; customerName: string; phone: string; address: string; items: LineData[]; total: number; status: string; createdAt: string };
type SellRequestData = {
  id: number; sellerName: string; phone: string; address: string; materialName: string;
  category: string; description: string; quantityKg: number; expectedPricePerKg: number;
  status: 'pending' | 'accepted' | 'rejected'; createdAt: string;
};
type CartLine = { item: ScrapItemData; quantityKg: number };

const queryClient = new QueryClient();
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#236e63',
    colorForeground: '#1c2c32',
    colorMutedForeground: '#697579',
    colorDanger: '#bd453d',
    colorBackground: '#fbf8f0',
    colorInput: '#fffdf8',
    colorInputForeground: '#1c2c32',
    colorNeutral: '#d8d0c1',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '0.8rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fbf8f0] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#d8d0c1]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'font-display text-[#1c2c32]',
    headerSubtitle: 'text-[#697579]',
    socialButtonsBlockButtonText: 'text-[#1c2c32]',
    formFieldLabel: 'text-[#1c2c32]',
    footerActionLink: 'text-[#236e63]',
    footerActionText: 'text-[#697579]',
    dividerText: 'text-[#697579]',
    identityPreviewEditButton: 'text-[#236e63]',
    formFieldSuccessText: 'text-[#236e63]',
    alertText: 'text-[#bd453d]',
    logoBox: 'mb-2',
    logoImage: 'max-h-10',
    socialButtonsBlockButton: 'border-[#d8d0c1] bg-[#fffdf8]',
    formButtonPrimary: 'bg-[#236e63] hover:bg-[#1d5b52]',
    formFieldInput: 'border-[#d8d0c1] bg-[#fffdf8] text-[#1c2c32]',
    footerAction: 'bg-transparent',
    dividerLine: 'bg-[#d8d0c1]',
    alert: 'border-[#bd453d] bg-[#bd453d]/10',
    otpCodeFieldInput: 'border-[#d8d0c1] bg-[#fffdf8] text-[#1c2c32]',
    formFieldRow: 'text-[#1c2c32]',
    main: 'bg-transparent',
  },
};

const money = (value: number) => `₹${value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const dateLabel = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? value : date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
};
const artClass = (category: string) => {
  const value = category.toLowerCase();
  if (value.includes('copper') || value.includes('metal') || value.includes('wire')) return 'art-copper';
  if (value.includes('paper') || value.includes('card')) return 'art-paper';
  if (value.includes('glass')) return 'art-glass';
  return 'art-plastic';
};

const CartContext = createContext<{
  lines: CartLine[];
  total: number;
  count: number;
  addItem: (item: ScrapItemData) => void;
  changeQuantity: (id: number, amount: number) => void;
  removeItem: (id: number) => void;
  clear: () => void;
} | null>(null);

function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(() => {
    try {
      const saved = localStorage.getItem('scrapsetu-cart');
      return saved ? JSON.parse(saved) as CartLine[] : [];
    } catch {
      return [];
    }
  });
  useEffect(() => { localStorage.setItem('scrapsetu-cart', JSON.stringify(lines)); }, [lines]);
  const addItem = (item: ScrapItemData) => setLines((current) => {
    const existing = current.find((line) => line.item.id === item.id);
    if (existing) return current.map((line) => line.item.id === item.id ? { ...line, quantityKg: Math.min(line.quantityKg + 1, item.stockKg) } : line);
    return [...current, { item, quantityKg: Math.min(1, item.stockKg) }];
  });
  const changeQuantity = (id: number, amount: number) => setLines((current) => current.map((line) => line.item.id === id
    ? { ...line, quantityKg: Math.max(.1, Math.min(line.item.stockKg, Math.round((line.quantityKg + amount) * 10) / 10)) } : line));
  const removeItem = (id: number) => setLines((current) => current.filter((line) => line.item.id !== id));
  const total = lines.reduce((sum, line) => sum + line.item.pricePerKg * line.quantityKg, 0);
  const count = lines.reduce((sum, line) => sum + line.quantityKg, 0);
  return <CartContext.Provider value={{ lines, total, count, addItem, changeQuantity, removeItem, clear: () => setLines([]) }}>{children}</CartContext.Provider>;
}
function useCart() {
  const value = useContext(CartContext);
  if (!value) throw new Error('Cart context is missing');
  return value;
}

const NoticeContext = createContext<((message: string) => void) | null>(null);
function useNotice() { return useContext(NoticeContext) ?? (() => undefined); }

function AuthActions() {
  const { isLoaded, isSignedIn, user } = useUser();
  const { signOut } = useClerk();

  if (!isLoaded) return null;
  if (!isSignedIn) {
    return <Link href="/sign-in?redirect=/admin" className="nav-link" data-testid="link-admin-login">Admin login</Link>;
  }

  const displayName = user?.firstName || user?.emailAddresses[0]?.emailAddress?.split('@')[0] || 'Account';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
      <span className="section-note" style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{displayName}</span>
      <button className="button button-ghost" type="button" onClick={() => void signOut({ redirectUrl: basePath || '/' })} data-testid="button-sign-out">Sign out</button>
    </div>
  );
}

function Header() {
  const [location] = useLocation();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const nav = [
    { href: '/', label: 'Browse', icon: Search },
    { href: '/sell-scrap', label: 'Sell scrap', icon: HandCoins },
    { href: '/orders', label: 'My requests', icon: ClipboardList },
    { href: '/admin', label: 'Admin panel', icon: LayoutDashboard },
  ];
  return (
    <header className="app-header">
      <div className="header-inner">
        <Link href="/" className="brand" data-testid="link-brand" onClick={() => setOpen(false)}>
          <span className="brand-mark"><Recycle size={21} strokeWidth={2.6} /></span>
          <span className="brand-name">Scrap<span>Setu</span></span>
        </Link>
        <nav className={`main-nav ${open ? 'open' : ''}`} aria-label="Primary navigation">
          {nav.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`} onClick={() => setOpen(false)}>
              <Icon size={16} />{label}
            </Link>
          ))}
        </nav>
        <div className="header-tools">
          <AuthActions />
          <Link href="/cart" className="cart-pill" data-testid="link-cart"><ShoppingCart size={17} /><span>Cart</span><span className="cart-count" data-testid="text-cart-count">{count || 0}</span></Link>
          <button className="mobile-menu" type="button" aria-label="Toggle navigation" data-testid="button-toggle-menu" onClick={() => setOpen((value) => !value)}>{open ? <X size={21} /> : <Menu size={21} />}</button>
        </div>
      </div>
    </header>
  );
}

function Layout({ children }: { children: ReactNode }) {
  const [notice, setNotice] = useState('');
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });
  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(''), 3000);
    return () => window.clearTimeout(timeout);
  }, [notice]);
  return (
    <NoticeContext.Provider value={setNotice}>
      <div className="page-shell">
        <Header />
        {children}
        <div className="content-wrap" style={{ paddingTop: 0, paddingBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'hsl(var(--muted-foreground))', fontSize: '.72rem' }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: health.isError ? 'hsl(var(--destructive))' : 'hsl(var(--primary))' }} />
            {health.isError ? 'Seller network is reconnecting' : 'A local exchange for useful materials'}
          </div>
        </div>
        {notice && <div className="toast-note" data-testid="status-toast">{notice}</div>}
      </div>
    </NoticeContext.Provider>
  );
}

function ProductCard({ item }: { item: ScrapItemData }) {
  const { addItem } = useCart();
  const notify = useNotice();
  const soldOut = item.status !== 'active' || item.stockKg <= 0;
  const handleAdd = () => { addItem(item); notify(`${item.name} added to your pickup list`); };
  return (
    <article className="product-card animate-rise" data-testid={`card-product-${item.id}`}>
      <div className={`product-art ${artClass(item.category)}`}><span className="art-label">{item.name}</span></div>
      <div className="product-body">
        <div className="product-meta"><span className="badge"><Zap size={11} /> {item.category}</span><span className={`badge ${soldOut ? 'badge-red' : 'badge-warm'}`}>{soldOut ? 'Unavailable' : `${item.stockKg} kg ready`}</span></div>
        <h3 className="product-title">{item.name}</h3>
        <p className="product-desc">{item.description || 'Sorted material, ready for a local pickup.'}</p>
        <div className="product-foot">
          <div className="price">{money(item.pricePerKg)} <small>per kilogram</small></div>
          <button className="button button-primary" type="button" disabled={soldOut} onClick={handleAdd} data-testid={`button-add-item-${item.id}`}><Plus size={16} /> Add kg</button>
        </div>
      </div>
    </article>
  );
}

function Home() {
  const params = useMemo(() => ({ status: 'active' as const }), []);
  const itemsQuery = useListScrapItems(params);
  const categoriesQuery = useListCategories();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All materials');
  const items = (itemsQuery.data ?? []) as ScrapItemData[];
  const categories = (categoriesQuery.data ?? []) as CategoryData[];
  const visibleItems = useMemo(() => items.filter((item) => {
    const matchesSearch = `${item.name} ${item.category} ${item.description}`.toLowerCase().includes(search.toLowerCase());
    return matchesSearch && (category === 'All materials' || item.category === category);
  }), [items, search, category]);
  return (
    <main className="content-wrap">
      <section className="hero animate-rise">
        <div className="hero-copy">
          <div className="eyebrow">The neighbourhood materials exchange</div>
          <h1>Good scrap.<br />Better loops.</h1>
          <p>Buy sorted recyclable materials from nearby sellers, by the kilogram. Clear prices, simple pickup requests, and a little more value kept in the community.</p>
          <Link href="#materials" className="button button-secondary" style={{ marginTop: 27 }} data-testid="link-browse-materials">Browse the live lot <ArrowRight size={16} /></Link>
        </div>
        <div className="hero-stamp">SORTED<br />NEARBY<br /><span>SETU / 01</span></div>
      </section>
      <section id="materials">
        <div className="section-head">
          <div><div className="eyebrow">Today's lot</div><h2>Materials with a next stop.</h2></div>
          <div className="section-note" data-testid="text-material-count">{items.length ? `${items.length} live listings` : 'New listings land here daily'}</div>
        </div>
        <div className="toolbar">
          <label className="search-input" style={{ position: 'relative' }}>
            <Search size={17} style={{ position: 'absolute', left: 13, top: 13, color: 'hsl(var(--muted-foreground))' }} />
            <input className="input" style={{ paddingLeft: 40 }} type="search" value={search} placeholder="Search copper, cartons, glass..." onChange={(event) => setSearch(event.target.value)} data-testid="input-search-items" />
          </label>
          <select className="select filter-select" value={category} onChange={(event) => setCategory(event.target.value)} data-testid="select-category-filter">
            <option>All materials</option>
            {categories.map((item) => <option key={item.id} value={item.name}>{item.name} ({item.itemCount})</option>)}
          </select>
        </div>
        <div className="category-strip">
          <button className={`category-chip ${category === 'All materials' ? 'active' : ''}`} type="button" onClick={() => setCategory('All materials')} data-testid="button-category-all"><span className="category-dot" />All materials</button>
          {categories.map((item) => <button className={`category-chip ${category === item.name ? 'active' : ''}`} type="button" key={item.id} onClick={() => setCategory(item.name)} data-testid={`button-category-${item.id}`}><span className="category-dot" />{item.name}</button>)}
        </div>
        {itemsQuery.isLoading ? <div className="product-grid">{[1, 2, 3].map((item) => <div className="product-card" key={item}><div className="skeleton" style={{ height: 174 }} /><div style={{ padding: 17 }}><div className="skeleton" style={{ height: 18, width: '48%' }} /><div className="skeleton" style={{ height: 48, marginTop: 17 }} /></div></div>)}</div>
          : itemsQuery.isError ? <div className="error-panel" data-testid="status-items-error"><strong>We couldn't load the live lot.</strong><p style={{ margin: '6px 0 12px' }}>The seller network may be taking a short pause.</p><button className="button button-ghost" type="button" onClick={() => void itemsQuery.refetch()} data-testid="button-retry-items">Try again</button></div>
            : visibleItems.length ? <div className="product-grid">{visibleItems.map((item) => <ProductCard key={item.id} item={item} />)}</div>
              : <div className="empty-state" data-testid="status-items-empty"><div className="empty-icon"><Archive size={25} /></div><h3>No matching materials yet.</h3><p>Try another search, or check back after local sellers finish their next sort.</p><button className="button button-ghost" style={{ marginTop: 18 }} type="button" onClick={() => { setSearch(''); setCategory('All materials'); }} data-testid="button-clear-filters">Clear filters</button></div>}
      </section>
      <section className="two-col" style={{ marginTop: 68 }}>
        <div className="panel animate-rise delay-1"><div className="eyebrow">How ScrapSetu works</div><h2 style={{ fontSize: '2rem', marginTop: 9 }}>A simple handoff,<br />with fewer dead ends.</h2><div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, marginTop: 26 }}>{[['01', 'Choose', 'Pick a sorted lot and add the kilograms you need.'], ['02', 'Request', 'Share a phone number and a useful pickup address.'], ['03', 'Reuse', 'The material gets a new route, not a landfill stop.']].map(([number, title, copy]) => <div key={number}><div className="font-mono" style={{ color: 'hsl(var(--secondary))', fontSize: '.72rem' }}>{number}</div><strong style={{ display: 'block', marginTop: 12 }}>{title}</strong><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.8rem', lineHeight: 1.5 }}>{copy}</p></div>)}</div></div>
        <div className="panel animate-rise delay-2" style={{ background: 'hsl(var(--secondary) / .16)' }}><div style={{ display: 'flex', justifyContent: 'space-between' }}><Truck size={28} color="hsl(var(--primary))" /><span className="badge badge-warm">Local first</span></div><h3 style={{ fontSize: '1.55rem', marginTop: 40 }}>Every kilogram has a story after you.</h3><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.86rem', lineHeight: 1.6 }}>Sellers set the lot. You set the pace. We make the handoff clear.</p></div>
      </section>
    </main>
  );
}

function SellScrap() {
  const createRequest = useCreateSellRequest();
  const notify = useNotice();
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    sellerName: '',
    phone: '',
    address: '',
    materialName: '',
    category: '',
    description: '',
    quantityKg: '',
    expectedPricePerKg: '',
  });

  const updateField = (field: keyof typeof form, value: string) =>
    setForm((current) => ({ ...current, [field]: value }));

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const quantityKg = Number(form.quantityKg);
    const expectedPricePerKg = Number(form.expectedPricePerKg);
    if (
      !form.sellerName.trim() ||
      form.phone.trim().length < 7 ||
      !form.address.trim() ||
      !form.materialName.trim() ||
      !form.category.trim() ||
      !form.description.trim() ||
      !Number.isFinite(quantityKg) ||
      quantityKg < 0.1 ||
      !Number.isFinite(expectedPricePerKg) ||
      expectedPricePerKg < 0
    ) {
      setError('Please fill all details, quantity, and your expected price correctly.');
      return;
    }

    setError('');
    createRequest.mutate(
      {
        data: {
          sellerName: form.sellerName.trim(),
          phone: form.phone.trim(),
          address: form.address.trim(),
          materialName: form.materialName.trim(),
          category: form.category.trim(),
          description: form.description.trim(),
          quantityKg,
          expectedPricePerKg,
        },
      },
      {
        onSuccess: () => {
          setSubmitted(true);
          notify('Your scrap request has been sent to the admin.');
          setForm({
            sellerName: '',
            phone: '',
            address: '',
            materialName: '',
            category: '',
            description: '',
            quantityKg: '',
            expectedPricePerKg: '',
          });
        },
        onError: () => setError('We could not send your request. Please try again.'),
      },
    );
  };

  return (
    <main className="content-wrap">
      <div className="eyebrow">Apna scrap bechein · Sell your scrap</div>
      <h1 className="page-title">Have scrap to sell?</h1>
      <p className="page-lede">
        Tell us what you have, how much you have, and the price you expect.
        The admin will review your request and contact you.
      </p>
      <div className="two-col" style={{ marginTop: 38 }}>
        <section className="panel">
          <div className="section-head" style={{ margin: 0 }}>
            <div>
              <div className="eyebrow">Your offer</div>
              <h2>Share the details</h2>
            </div>
            <HandCoins size={28} color="hsl(var(--secondary))" />
          </div>
          {submitted ? (
            <div className="empty-state" style={{ marginTop: 24 }}>
              <div className="empty-icon"><Check size={24} /></div>
              <h3>Request received.</h3>
              <p>Your offer is now with the admin. We will review the details and get in touch.</p>
              <button className="button button-primary" type="button" style={{ marginTop: 18 }} onClick={() => setSubmitted(false)} data-testid="button-send-another-sell-request">Send another request</button>
            </div>
          ) : (
            <form className="form-grid" style={{ marginTop: 22 }} onSubmit={submit}>
              <label><span className="field-label">Your name / आपका नाम</span><input className="input" value={form.sellerName} onChange={(event) => updateField('sellerName', event.target.value)} placeholder="Full name" data-testid="input-sell-name" /></label>
              <label><span className="field-label">Phone number / मोबाइल</span><input className="input" value={form.phone} onChange={(event) => updateField('phone', event.target.value)} placeholder="10 digit number" inputMode="tel" data-testid="input-sell-phone" /></label>
              <label><span className="field-label">Address / pickup location</span><textarea className="textarea" value={form.address} onChange={(event) => updateField('address', event.target.value)} placeholder="Full address with a nearby landmark" data-testid="input-sell-address" /></label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <label><span className="field-label">Scrap material</span><input className="input" value={form.materialName} onChange={(event) => updateField('materialName', event.target.value)} placeholder="Copper wire" data-testid="input-sell-material" /></label>
                <label><span className="field-label">Category</span><input className="input" value={form.category} onChange={(event) => updateField('category', event.target.value)} placeholder="Metal" data-testid="input-sell-category" /></label>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <label><span className="field-label">Quantity in kg</span><input className="input" type="number" min="0.1" step=".1" value={form.quantityKg} onChange={(event) => updateField('quantityKg', event.target.value)} placeholder="25" data-testid="input-sell-quantity" /></label>
                <label><span className="field-label">Expected price / kg</span><input className="input" type="number" min="0" step=".01" value={form.expectedPricePerKg} onChange={(event) => updateField('expectedPricePerKg', event.target.value)} placeholder="180" data-testid="input-sell-price" /></label>
              </div>
              <label><span className="field-label">Scrap details</span><textarea className="textarea" value={form.description} onChange={(event) => updateField('description', event.target.value)} placeholder="Tell us about quality, sorting, condition, or photos you can share." data-testid="input-sell-description" /></label>
              {error && <div className="error-panel" data-testid="status-sell-request-error">{error}</div>}
              <button className="button button-primary" type="submit" disabled={createRequest.isPending} data-testid="button-submit-sell-request">{createRequest.isPending ? 'Sending...' : 'Send scrap request'} <ArrowRight size={16} /></button>
              <p style={{ margin: 0, color: 'hsl(var(--muted-foreground))', fontSize: '.7rem', lineHeight: 1.5 }}>Your request will be reviewed before any pickup or payment is confirmed.</p>
            </form>
          )}
        </section>
        <aside className="panel" style={{ background: 'hsl(var(--secondary) / .16)', alignSelf: 'start' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><Truck size={28} color="hsl(var(--primary))" /><span className="badge badge-warm">Admin reviewed</span></div>
          <h2 style={{ fontSize: '1.8rem', marginTop: 34 }}>How it works</h2>
          <div style={{ display: 'grid', gap: 20, marginTop: 24 }}>
            {[
              ['01', 'Share your offer', 'Fill in your material, quantity, expected price, and contact details.'],
              ['02', 'Admin reviews', 'The request appears in the Scrap requests tab of the admin panel.'],
              ['03', 'Get a response', 'The admin accepts or rejects the request and contacts you for the next step.'],
            ].map(([number, title, copy]) => <div key={number}><div className="font-mono" style={{ color: 'hsl(var(--secondary))', fontSize: '.72rem' }}>{number}</div><strong style={{ display: 'block', marginTop: 7 }}>{title}</strong><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.82rem', lineHeight: 1.5, margin: '5px 0 0' }}>{copy}</p></div>)}
          </div>
        </aside>
      </div>
    </main>
  );
}

function Cart() {
  const { lines, total, changeQuantity, removeItem } = useCart();
  const createOrder = useCreateOrder();
  const notify = useNotice();
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({ customerName: '', phone: '', address: '' });
  const [error, setError] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!lines.length) { setError('Add at least one material before requesting a pickup.'); return; }
    if (form.customerName.trim().length < 1 || form.phone.trim().length < 7 || form.address.trim().length < 1) { setError('Please fill in your name, a reachable phone number, and pickup address.'); return; }
    setError('');
    createOrder.mutate({ data: { ...form, items: lines.map((line) => ({ scrapItemId: line.item.id, quantityKg: line.quantityKg })) } }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() }); queryClient.invalidateQueries({ queryKey: getListScrapItemsQueryKey() }); notify('Pickup request sent. The seller will confirm the handoff.'); setLocation('/orders'); },
      onError: () => setError('This request could not be sent. Please try again in a moment.'),
    });
  };
  return (
    <main className="content-wrap">
      <div className="eyebrow">Your pickup list</div><h1 className="page-title">Make it a handoff.</h1><p className="page-lede">Review your kilograms, then leave a few details so the nearby seller knows where to meet you.</p>
      <div className="two-col" style={{ marginTop: 38 }}>
        <section className="panel"><div className="section-head" style={{ margin: 0, paddingBottom: 9 }}><h2>Selected materials</h2><span className="section-note">{lines.length} {lines.length === 1 ? 'line' : 'lines'}</span></div>
          {lines.length ? lines.map((line) => <div className="cart-line" key={line.item.id} data-testid={`row-cart-item-${line.item.id}`}><div className={`mini-art ${artClass(line.item.category)}`} /><div><strong>{line.item.name}</strong><div style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.75rem', marginTop: 4 }}>{money(line.item.pricePerKg)} / kg · {money(line.item.pricePerKg * line.quantityKg)}</div><div className="qty-control" style={{ marginTop: 9 }}><button type="button" onClick={() => changeQuantity(line.item.id, -.1)} aria-label={`Decrease ${line.item.name}`} data-testid={`button-decrease-${line.item.id}`}><Minus size={13} /></button><span data-testid={`text-quantity-${line.item.id}`}>{line.quantityKg.toFixed(1)} kg</span><button type="button" onClick={() => changeQuantity(line.item.id, .1)} aria-label={`Increase ${line.item.name}`} data-testid={`button-increase-${line.item.id}`}><Plus size={13} /></button></div></div><button className="icon-button danger" type="button" onClick={() => removeItem(line.item.id)} aria-label={`Remove ${line.item.name}`} data-testid={`button-remove-${line.item.id}`}><Trash2 size={15} /></button></div>) : <div className="empty-state" style={{ marginTop: 18 }}><div className="empty-icon"><ShoppingBag size={24} /></div><h3>Your list is clear.</h3><p>Browse the live lot and add a few kilograms to start a request.</p><Link href="/" className="button button-primary" style={{ marginTop: 18 }} data-testid="link-empty-cart-browse">Browse materials <ArrowRight size={15} /></Link></div>}
          {lines.length > 0 && <div className="summary-total"><span>Total</span><span data-testid="text-cart-total">{money(total)}</span></div>}
        </section>
        <section className="panel"><div className="eyebrow">Pickup details</div><h2 style={{ fontSize: '1.8rem', marginTop: 8 }}>Where should we reach you?</h2><form className="form-grid" style={{ marginTop: 22 }} onSubmit={submit}><label><span className="field-label">Your name</span><input className="input" value={form.customerName} onChange={(event) => setForm({ ...form, customerName: event.target.value })} placeholder="Name for the seller" data-testid="input-customer-name" /></label><label><span className="field-label">Phone number</span><input className="input" value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} placeholder="10 digit number" inputMode="tel" data-testid="input-customer-phone" /></label><label><span className="field-label">Pickup address</span><textarea className="textarea" value={form.address} onChange={(event) => setForm({ ...form, address: event.target.value })} placeholder="A clear landmark helps a local handoff" data-testid="input-customer-address" /></label>{error && <div className="error-panel" data-testid="status-order-error">{error}</div>}<button className="button button-primary" type="submit" disabled={createOrder.isPending} data-testid="button-place-order">{createOrder.isPending ? 'Sending request...' : 'Request pickup'} <ArrowRight size={16} /></button><p style={{ margin: 0, color: 'hsl(var(--muted-foreground))', fontSize: '.7rem', lineHeight: 1.5 }}>No payment is taken here. The seller confirms availability and the final handoff directly.</p></form></section>
      </div>
    </main>
  );
}

function StatusTrack({ status }: { status: string }) {
  const steps = ['pending', 'confirmed', 'completed'];
  const current = status === 'cancelled' ? -1 : steps.indexOf(status);
  return <div className="status-track">{steps.map((step, index) => <span key={step} style={{ display: 'contents' }}><span className={`track-step ${index <= current ? 'done' : ''}`}>{index <= current ? <Check size={12} /> : <span style={{ width: 12, height: 12, border: '1px solid currentColor', borderRadius: '50%' }} />} {step}</span>{index < steps.length - 1 && <span className="track-line" />}</span>)}</div>;
}

function Orders() {
  const ordersQuery = useListOrders({ query: { queryKey: getListOrdersQueryKey() } });
  const orders = (ordersQuery.data ?? []) as OrderData[];
  return <main className="content-wrap"><div className="eyebrow">Your request log</div><h1 className="page-title">Handoffs in motion.</h1><p className="page-lede">Keep an eye on each local pickup request. You can come back here whenever you need the details.</p><div style={{ display: 'grid', gap: 14, marginTop: 40 }}>{ordersQuery.isLoading ? [1, 2].map((item) => <div className="panel" key={item}><div className="skeleton" style={{ height: 20, width: '40%' }} /><div className="skeleton" style={{ height: 54, marginTop: 16 }} /></div>) : ordersQuery.isError ? <div className="error-panel" data-testid="status-orders-error">We couldn't load your request history. <button className="button button-ghost" type="button" onClick={() => void ordersQuery.refetch()} data-testid="button-retry-orders">Try again</button></div> : orders.length ? orders.map((order) => <article className="order-card animate-rise" key={order.id} data-testid={`card-order-${order.id}`}><div><div style={{ display: 'flex', alignItems: 'center', gap: 9 }}><span className="eyebrow">Request #{order.id}</span><span className={`badge ${order.status === 'cancelled' ? 'badge-red' : order.status === 'completed' ? 'badge-warm' : ''}`}>{order.status}</span></div><h2 style={{ fontSize: '1.45rem', marginTop: 9 }}>{money(order.total)} <span style={{ color: 'hsl(var(--muted-foreground))', fontFamily: 'var(--app-font-sans)', fontSize: '.78rem', fontWeight: 500 }}>· {dateLabel(order.createdAt)}</span></h2><div className="order-items">{order.items.map((item) => <span className="order-item-chip" key={item.scrapItemId}>{item.itemName} · {item.quantityKg} kg</span>)}</div><StatusTrack status={order.status} /></div><div style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.78rem', lineHeight: 1.6, maxWidth: 200 }}><strong style={{ color: 'hsl(var(--foreground))' }}>{order.customerName}</strong><br />{order.address}<br />{order.phone}</div></article>) : <div className="empty-state" data-testid="status-orders-empty"><div className="empty-icon"><ClipboardList size={24} /></div><h3>No requests yet.</h3><p>Your first sorted-material pickup will appear here after you send the request.</p><Link href="/" className="button button-primary" style={{ marginTop: 18 }} data-testid="link-orders-browse">Find materials <ArrowRight size={15} /></Link></div>}</div></main>;
}

function AuthRequired({ title, description }: { title: string; description: string }) {
  return (
    <main className="content-wrap">
      <div className="panel" style={{ maxWidth: 620, margin: '42px auto', textAlign: 'center' }}>
        <div className="eyebrow">ScrapSetu account</div>
        <h1 className="page-title" style={{ fontSize: 'clamp(2rem, 5vw, 3.6rem)' }}>{title}</h1>
        <p className="page-lede" style={{ marginInline: 'auto' }}>{description}</p>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginTop: 26, flexWrap: 'wrap' }}>
          <Link href="/sign-in" className="button button-primary" data-testid="link-required-sign-in">Sign in to continue <ArrowRight size={16} /></Link>
          <Link href="/sign-up" className="button button-ghost" data-testid="link-required-sign-up">Create account</Link>
        </div>
      </div>
    </main>
  );
}

function Protected({ children, title, description }: { children: ReactNode; title: string; description: string }) {
  const { isLoaded, isSignedIn } = useUser();
  if (!isLoaded) {
    return <main className="content-wrap"><div className="panel" style={{ maxWidth: 620, margin: '42px auto' }}><div className="skeleton" style={{ height: 180 }} /></div></main>;
  }
  return isSignedIn ? <>{children}</> : <AuthRequired title={title} description={description} />;
}

function SellerGate() {
  return <Protected title="Your admin panel is waiting." description="Sign in to manage scrap listings, stock, categories, prices, and customer requests."><Admin /></Protected>;
}

function OrdersGate() {
  return <Protected title="Keep your requests together." description="Sign in to view your pickup requests and follow each handoff from pending to completed."><Orders /></Protected>;
}

function Modal({ title, description, onClose, children }: { title: string; description: string; onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="modal" role="dialog" aria-modal="true"><div className="modal-head"><div><h2>{title}</h2><p>{description}</p></div><button className="modal-close" type="button" onClick={onClose} aria-label="Close dialog" data-testid="button-close-modal"><X size={20} /></button></div>{children}</div></div>;
}

function Admin() {
  const [tab, setTab] = useState<'overview' | 'inventory' | 'categories' | 'orders' | 'sell-requests'>('overview');
  const notify = useNotice();
  const [showItemForm, setShowItemForm] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  const [itemForm, setItemForm] = useState({ name: '', category: '', description: '', pricePerKg: '', stockKg: '', imageUrl: '' });
  const [categoryName, setCategoryName] = useState('');
  const [adminError, setAdminError] = useState('');
  const summaryQuery = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const itemsQuery = useListScrapItems(undefined, { query: { queryKey: getListScrapItemsQueryKey() } });
  const categoriesQuery = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });
  const ordersQuery = useListOrders({ query: { queryKey: getListOrdersQueryKey() } });
  const sellRequestsQuery = useListSellRequests({ query: { queryKey: getListSellRequestsQueryKey() } });
  const detailQuery = useGetScrapItem(selectedItemId ?? 0, { query: { enabled: selectedItemId !== null, queryKey: getGetScrapItemQueryKey(selectedItemId ?? 0) } });
  const createItem = useCreateScrapItem();
  const createCategory = useCreateCategory();
  const updateItem = useUpdateScrapItem();
  const deleteItem = useDeleteScrapItem();
  const updateSellRequest = useUpdateSellRequest();
  const items = (itemsQuery.data ?? []) as ScrapItemData[];
  const categories = (categoriesQuery.data ?? []) as CategoryData[];
  const orders = (ordersQuery.data ?? []) as OrderData[];
  const sellRequests = (sellRequestsQuery.data ?? []) as SellRequestData[];
  const fallbackSummary = { totalItems: items.length, activeItems: items.filter((item) => item.status === 'active').length, totalStockKg: items.reduce((sum, item) => sum + item.stockKg, 0), pendingOrders: orders.filter((order) => order.status === 'pending').length, totalSales: orders.reduce((sum, order) => sum + order.total, 0) };
  const summary = summaryQuery.data ?? fallbackSummary;
  const invalidateInventory = () => { queryClient.invalidateQueries({ queryKey: getListScrapItemsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }); };
  const submitItem = (event: FormEvent) => {
    event.preventDefault();
    if (!itemForm.name.trim() || !itemForm.category.trim() || Number(itemForm.pricePerKg) < 0 || Number(itemForm.stockKg) < 0) { setAdminError('Name, category, price, and stock are required.'); return; }
    createItem.mutate({ data: { ...itemForm, pricePerKg: Number(itemForm.pricePerKg), stockKg: Number(itemForm.stockKg), imageUrl: itemForm.imageUrl } }, { onSuccess: () => { invalidateInventory(); setShowItemForm(false); setItemForm({ name: '', category: '', description: '', pricePerKg: '', stockKg: '', imageUrl: '' }); setAdminError(''); }, onError: () => setAdminError('Could not add this listing. Check the details and try again.') });
  };
  const submitCategory = (event: FormEvent) => {
    event.preventDefault();
    if (!categoryName.trim()) { setAdminError('Add a name for the category.'); return; }
    createCategory.mutate({ data: { name: categoryName.trim() } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListCategoriesQueryKey() }); setCategoryName(''); setShowCategoryForm(false); setAdminError(''); }, onError: () => setAdminError('This category could not be created.') });
  };
  const toggleItem = (item: ScrapItemData) => updateItem.mutate({ id: item.id, data: { status: item.status === 'active' ? 'hidden' : 'active' } }, { onSuccess: invalidateInventory });
  const removeItem = (item: ScrapItemData) => { if (window.confirm(`Remove ${item.name} from the inventory?`)) deleteItem.mutate({ id: item.id }, { onSuccess: invalidateInventory }); };
  const updateSellRequestStatus = (request: SellRequestData, status: 'accepted' | 'rejected') => {
    updateSellRequest.mutate(
      { id: request.id, data: { status } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSellRequestsQueryKey() });
          notify(`${request.materialName} request ${status}.`);
        },
        onError: () => setAdminError('This scrap request could not be updated. Please try again.'),
      },
    );
  };
  const tabItems = [{ id: 'overview', label: 'Overview', icon: BarChart3 }, { id: 'inventory', label: 'Inventory', icon: Database }, { id: 'categories', label: 'Categories', icon: Archive }, { id: 'orders', label: 'Orders', icon: ClipboardList }, { id: 'sell-requests', label: 'Scrap requests', icon: HandCoins }] as const;
  return <main className="content-wrap"><div className="admin-layout"><aside className="admin-nav"><div className="admin-nav-title">Admin panel</div>{tabItems.map(({ id, label, icon: Icon }) => <button className={`admin-tab ${tab === id ? 'active' : ''}`} type="button" key={id} onClick={() => setTab(id)} data-testid={`button-admin-tab-${id}`}><Icon size={16} />{label}</button>)}</aside><section style={{ minWidth: 0 }}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 18, marginBottom: 28 }}><div><div className="eyebrow">ScrapSetu / admin workspace</div><h1 className="page-title" style={{ fontSize: 'clamp(2rem, 4vw, 3.8rem)' }}>{tab === 'overview' ? 'Keep the loop moving.' : tabItems.find((item) => item.id === tab)?.label}</h1></div>{tab === 'inventory' && <button className="button button-primary" type="button" onClick={() => setShowItemForm(true)} data-testid="button-open-item-form"><PackagePlus size={16} /> Add listing</button>}{tab === 'categories' && <button className="button button-secondary" type="button" onClick={() => setShowCategoryForm(true)} data-testid="button-open-category-form"><Plus size={16} /> New category</button>}</div>
      {tab === 'overview' && <><div className="stat-grid">{[['Listings', summary.totalItems], ['Active now', summary.activeItems], ['Stock kg', summary.totalStockKg.toFixed(1)], ['Pending', summary.pendingOrders], ['Sales', money(summary.totalSales)]].map(([label, value]) => <div className="stat-card" key={label as string} data-testid={`stat-${String(label).toLowerCase().replace(' ', '-')}`}><div className="stat-label">{label}</div><div className="stat-value">{value}</div></div>)}</div><div className="two-col" style={{ marginTop: 22 }}><div className="panel"><div className="section-head" style={{ margin: 0 }}><div><div className="eyebrow">Latest listings</div><h2>Inventory pulse</h2></div><button className="button button-ghost" type="button" onClick={() => setTab('inventory')} data-testid="button-view-inventory">View all <ArrowRight size={14} /></button></div>{items.slice(0, 4).map((item) => <div key={item.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '15px 0', borderBottom: '1px solid hsl(var(--border) / .7)' }}><div><strong>{item.name}</strong><div style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.75rem', marginTop: 4 }}>{item.category} · {item.stockKg} kg</div></div><span className="badge">{item.status}</span></div>)}{!items.length && <p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.85rem' }}>No listings yet. Add your first sorted lot.</p>}</div><div className="panel" style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}><Truck size={28} color="hsl(var(--accent))" /><h2 style={{ fontSize: '1.8rem', marginTop: 30 }}>The seller promise.</h2><p style={{ color: 'hsl(var(--primary-foreground) / .72)', lineHeight: 1.65, fontSize: '.87rem' }}>Keep descriptions honest, prices visible, and stock ready for a real handoff. Trust is an inventory feature.</p><button className="button button-secondary" type="button" onClick={() => setTab('orders')} data-testid="button-view-orders">Review requests</button></div></div></>}
      {tab === 'inventory' && <div className="panel"><div className="section-head" style={{ margin: 0 }}><div><div className="eyebrow">Every lot, accounted for</div><h2>Inventory manager</h2></div><span className="section-note">{items.length} records</span></div>{itemsQuery.isLoading ? <div className="skeleton" style={{ height: 240, marginTop: 20 }} /> : <div className="table-wrap" style={{ marginTop: 18 }}><table className="data-table"><thead><tr><th>Material</th><th>Category</th><th>Price / kg</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody>{items.map((item) => <tr key={item.id} data-testid={`row-inventory-${item.id}`}><td><strong>{item.name}</strong><div style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.7rem', marginTop: 3 }}>{dateLabel(item.createdAt)}</div></td><td>{item.category}</td><td className="font-mono">{money(item.pricePerKg)}</td><td className="font-mono">{item.stockKg} kg</td><td><span className={`badge ${item.status === 'hidden' ? 'badge-red' : ''}`}>{item.status}</span></td><td><div className="table-actions"><button className="icon-button" type="button" onClick={() => setSelectedItemId(item.id)} aria-label={`View ${item.name}`} data-testid={`button-view-item-${item.id}`}><Edit3 size={14} /></button><button className="icon-button" type="button" onClick={() => toggleItem(item)} disabled={updateItem.isPending} aria-label={`Toggle ${item.name}`} data-testid={`button-toggle-item-${item.id}`}><Check size={14} /></button><button className="icon-button danger" type="button" onClick={() => removeItem(item)} disabled={deleteItem.isPending} aria-label={`Delete ${item.name}`} data-testid={`button-delete-item-${item.id}`}><Trash2 size={14} /></button></div></td></tr>)}</tbody></table>{!items.length && <div className="empty-state" style={{ marginTop: 18 }}><div className="empty-icon"><PackagePlus size={23} /></div><h3>Your inventory is waiting.</h3><p>Add a material lot to make it available to nearby customers.</p></div>}</div>}</div>}
      {tab === 'categories' && <div className="product-grid">{categories.map((category) => <div className="panel" key={category.id} data-testid={`card-category-${category.id}`}><div className="category-dot" /><h2 style={{ fontSize: '1.45rem', marginTop: 22 }}>{category.name}</h2><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.8rem' }}>{category.itemCount} listed materials</p></div>)}{!categories.length && <div className="empty-state" style={{ gridColumn: '1 / -1' }}><div className="empty-icon"><Archive size={23} /></div><h3>No categories yet.</h3><p>Create a category to help customers browse by material.</p></div>}</div>}
      {tab === 'orders' && <div className="panel"><div className="section-head" style={{ margin: 0 }}><div><div className="eyebrow">Customer handoffs</div><h2>Order overview</h2></div><span className="section-note">{orders.length} requests</span></div>{orders.length ? <div style={{ display: 'grid', gap: 12, marginTop: 18 }}>{orders.map((order) => <div className="order-card" key={order.id} data-testid={`admin-order-${order.id}`}><div><span className="eyebrow">#{order.id} · {dateLabel(order.createdAt)}</span><h3 style={{ marginTop: 8, fontSize: '1.1rem' }}>{order.customerName}</h3><div className="order-items">{order.items.map((line) => <span className="order-item-chip" key={line.scrapItemId}>{line.itemName} · {line.quantityKg} kg</span>)}</div></div><div style={{ textAlign: 'right' }}><span className="badge">{order.status}</span><div className="font-mono" style={{ marginTop: 13 }}>{money(order.total)}</div></div></div>)}</div> : <div className="empty-state" style={{ marginTop: 18 }}><div className="empty-icon"><ClipboardList size={23} /></div><h3>No customer requests.</h3><p>New pickup requests will be collected here for a clear seller handoff.</p></div>}</div>}
       {tab === 'sell-requests' && <div className="panel"><div className="section-head" style={{ margin: 0 }}><div><div className="eyebrow">Offers from local sellers</div><h2>Scrap requests</h2></div><span className="section-note">{sellRequests.filter((request) => request.status === 'pending').length} pending</span></div>{sellRequestsQuery.isLoading ? <div className="skeleton" style={{ height: 240, marginTop: 20 }} /> : sellRequestsQuery.isError ? <div className="error-panel" style={{ marginTop: 18 }}>Could not load scrap requests. <button className="button button-ghost" type="button" onClick={() => void sellRequestsQuery.refetch()}>Try again</button></div> : sellRequests.length ? <div style={{ display: 'grid', gap: 14, marginTop: 18 }}>{sellRequests.map((request) => <article className="order-card" key={request.id} data-testid={`card-sell-request-${request.id}`}><div><div style={{ display: 'flex', alignItems: 'center', gap: 9, flexWrap: 'wrap' }}><span className="eyebrow">Offer #{request.id} · {dateLabel(request.createdAt)}</span><span className={`badge ${request.status === 'rejected' ? 'badge-red' : request.status === 'accepted' ? 'badge-warm' : ''}`}>{request.status}</span></div><h3 style={{ marginTop: 9, fontSize: '1.25rem' }}>{request.materialName}</h3><div className="order-items"><span className="order-item-chip">{request.category}</span><span className="order-item-chip">{request.quantityKg} kg</span><span className="order-item-chip">{money(request.expectedPricePerKg)} / kg</span><span className="order-item-chip">Offer value {money(request.expectedPricePerKg * request.quantityKg)}</span></div><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.82rem', lineHeight: 1.55, margin: '12px 0 0' }}>{request.description}</p></div><div style={{ minWidth: 185, color: 'hsl(var(--muted-foreground))', fontSize: '.78rem', lineHeight: 1.6 }}><strong style={{ color: 'hsl(var(--foreground))' }}>{request.sellerName}</strong><br />{request.phone}<br />{request.address}{request.status === 'pending' && <div style={{ display: 'flex', gap: 7, marginTop: 14, justifyContent: 'flex-end' }}><button className="button button-primary" type="button" disabled={updateSellRequest.isPending} onClick={() => updateSellRequestStatus(request, 'accepted')} data-testid={`button-accept-sell-request-${request.id}`}><Check size={14} /> Accept</button><button className="button button-danger" type="button" disabled={updateSellRequest.isPending} onClick={() => updateSellRequestStatus(request, 'rejected')} data-testid={`button-reject-sell-request-${request.id}`}>Reject</button></div>}</div></article>)}</div> : <div className="empty-state" style={{ marginTop: 18 }}><div className="empty-icon"><HandCoins size={23} /></div><h3>No scrap offers yet.</h3><p>Requests from people who want to sell scrap will appear here.</p></div>}</div>}
    </section></div>
    {showItemForm && <Modal title="Add a material lot" description="Make a sorted batch visible to nearby customers." onClose={() => setShowItemForm(false)}><form className="form-grid" onSubmit={submitItem}><label><span className="field-label">Material name</span><input className="input" value={itemForm.name} onChange={(event) => setItemForm({ ...itemForm, name: event.target.value })} placeholder="Bright copper wire" data-testid="input-item-name" /></label><label><span className="field-label">Category</span><input className="input" value={itemForm.category} onChange={(event) => setItemForm({ ...itemForm, category: event.target.value })} placeholder="Metals" data-testid="input-item-category" /></label><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}><label><span className="field-label">Price per kg</span><input className="input" type="number" min="0" step=".01" value={itemForm.pricePerKg} onChange={(event) => setItemForm({ ...itemForm, pricePerKg: event.target.value })} placeholder="180" data-testid="input-item-price" /></label><label><span className="field-label">Stock in kg</span><input className="input" type="number" min="0" step=".1" value={itemForm.stockKg} onChange={(event) => setItemForm({ ...itemForm, stockKg: event.target.value })} placeholder="24" data-testid="input-item-stock" /></label></div><label><span className="field-label">Short description</span><textarea className="textarea" value={itemForm.description} onChange={(event) => setItemForm({ ...itemForm, description: event.target.value })} placeholder="Sorted, dry, and bundled for easy collection." data-testid="input-item-description" /></label>{adminError && <div className="error-panel" data-testid="status-admin-error">{adminError}</div>}<button className="button button-primary" type="submit" disabled={createItem.isPending} data-testid="button-submit-item">{createItem.isPending ? 'Adding...' : 'Publish listing'} <ArrowRight size={15} /></button></form></Modal>}
    {showCategoryForm && <Modal title="Create a category" description="Give customers one more useful way to browse." onClose={() => setShowCategoryForm(false)}><form className="form-grid" onSubmit={submitCategory}><label><span className="field-label">Category name</span><input className="input" value={categoryName} onChange={(event) => setCategoryName(event.target.value)} placeholder="Textiles" data-testid="input-category-name" /></label>{adminError && <div className="error-panel" data-testid="status-category-error">{adminError}</div>}<button className="button button-secondary" type="submit" disabled={createCategory.isPending} data-testid="button-submit-category">{createCategory.isPending ? 'Creating...' : 'Create category'} <ArrowRight size={15} /></button></form></Modal>}
    {selectedItemId !== null && <Modal title={detailQuery.data?.name ?? 'Material details'} description="A quick look at the selected lot." onClose={() => setSelectedItemId(null)}>{detailQuery.isLoading ? <div className="skeleton" style={{ height: 180 }} /> : detailQuery.data ? <div><div className={`product-art ${artClass(detailQuery.data.category)}`} style={{ borderRadius: 14 }}><span className="art-label">{detailQuery.data.name}</span></div><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 18 }}><div className="panel" style={{ padding: 14 }}><div className="stat-label">Price</div><div className="font-mono" style={{ marginTop: 8 }}>{money(detailQuery.data.pricePerKg)} / kg</div></div><div className="panel" style={{ padding: 14 }}><div className="stat-label">Available</div><div className="font-mono" style={{ marginTop: 8 }}>{detailQuery.data.stockKg} kg</div></div></div><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.85rem', lineHeight: 1.6 }}>{detailQuery.data.description}</p></div> : <div className="error-panel">Could not load this material.</div>}</Modal>}
  </main>;
}

function Router() {
  return (
    <ErrorBoundary resetKey={window.location.pathname}>
      <Switch>
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route>
          <Layout>
            <Switch>
              <Route path="/" component={Home} />
              <Route path="/sell-scrap" component={SellScrap} />
              <Route path="/cart" component={Cart} />
              <Route path="/orders" component={OrdersGate} />
              <Route path="/admin" component={SellerGate} />
              <Route component={NotFound} />
            </Switch>
          </Layout>
        </Route>
      </Switch>
    </ErrorBoundary>
  );
}

function AuthRedirect({ defaultPath }: { defaultPath: string }) {
  const [, setLocation] = useLocation();
  const { isLoaded, isSignedIn } = useUser();
  const redirectPath = new URLSearchParams(window.location.search).get('redirect') || defaultPath;

  useEffect(() => {
    if (isLoaded && isSignedIn) setLocation(stripBase(redirectPath));
  }, [isLoaded, isSignedIn, redirectPath, setLocation]);

  return null;
}

function SignInPage() {
  return <div className="auth-page"><AuthRedirect defaultPath="/admin" /><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}

function SignUpPage() {
  return <div className="auth-page"><AuthRedirect defaultPath="/admin" /><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener]);
  return null;
}

function ClerkApp() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to manage your ScrapSetu account' } },
        signUp: { start: { title: 'Join ScrapSetu', subtitle: 'Create an account for simpler handoffs' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <CartProvider><Router /></CartProvider>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return <WouterRouter base={basePath}><ClerkApp /></WouterRouter>;
}

export default App;