import { db, categoriesTable, scrapItemsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

let seedChecked = false;
let seedPromise: Promise<void> | undefined;

async function seedIfNeeded(): Promise<void> {
  const existing = await db
    .select({ id: categoriesTable.id })
    .from(categoriesTable)
    .limit(1);

  if (existing.length === 0) {
    const categories = await db
      .insert(categoriesTable)
      .values([{ name: "Metals" }, { name: "Paper & Cardboard" }, { name: "Plastic" }])
      .returning();
    const categoryByName = new Map(categories.map((category) => [category.name, category.id]));

    await db.insert(scrapItemsTable).values([
      {
        name: "Mixed Copper Wire",
        categoryId: categoryByName.get("Metals")!,
        description: "Clean, sorted copper wire ready for recycling.",
        pricePerKg: 540,
        stockKg: 86,
        imageUrl: "",
        status: "active",
      },
      {
        name: "Aluminium Sheets",
        categoryId: categoryByName.get("Metals")!,
        description: "Lightweight aluminium offcuts, bundled by weight.",
        pricePerKg: 165,
        stockKg: 124,
        imageUrl: "",
        status: "active",
      },
      {
        name: "Corrugated Cardboard",
        categoryId: categoryByName.get("Paper & Cardboard")!,
        description: "Dry, flattened cardboard collected from local businesses.",
        pricePerKg: 24,
        stockKg: 310,
        imageUrl: "",
        status: "active",
      },
    ]);
  }

  seedChecked = true;
}

export function ensureSeedData(): Promise<void> {
  if (seedChecked) return Promise.resolve();
  seedPromise ??= seedIfNeeded().catch((error) => {
    seedPromise = undefined;
    throw error;
  });
  return seedPromise;
}

export async function findCategoryId(name: string): Promise<number> {
  const [existing] = await db
    .select({ id: categoriesTable.id })
    .from(categoriesTable)
    .where(eq(categoriesTable.name, name))
    .limit(1);

  if (existing) return existing.id;

  const [created] = await db
    .insert(categoriesTable)
    .values({ name })
    .returning({ id: categoriesTable.id });

  return created.id;
}