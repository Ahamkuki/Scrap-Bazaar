import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db, scrapSellRequestsTable } from "@workspace/db";
import {
  CreateSellRequestBody,
  CreateSellRequestResponse,
  ListSellRequestsResponse,
  UpdateSellRequestBody,
  UpdateSellRequestParams,
  UpdateSellRequestResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/sell-requests", requireAuth, async (_req, res): Promise<void> => {
  const requests = await db
    .select()
    .from(scrapSellRequestsTable)
    .orderBy(desc(scrapSellRequestsTable.createdAt));

  res.json(ListSellRequestsResponse.parse(requests));
});

router.post("/sell-requests", async (req, res): Promise<void> => {
  const parsed = CreateSellRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [created] = await db
    .insert(scrapSellRequestsTable)
    .values({
      ...parsed.data,
      sellerName: parsed.data.sellerName.trim(),
      phone: parsed.data.phone.trim(),
      address: parsed.data.address.trim(),
      materialName: parsed.data.materialName.trim(),
      category: parsed.data.category.trim(),
      description: parsed.data.description.trim(),
      status: "pending",
    })
    .returning();

  res.status(201).json(CreateSellRequestResponse.parse(created));
});

router.patch(
  "/sell-requests/:id",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = UpdateSellRequestParams.safeParse(req.params);
    const parsed = UpdateSellRequestBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const [updated] = await db
      .update(scrapSellRequestsTable)
      .set({ status: parsed.data.status })
      .where(eq(scrapSellRequestsTable.id, params.data.id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Scrap selling request not found" });
      return;
    }

    res.json(UpdateSellRequestResponse.parse(updated));
  },
);

export default router;