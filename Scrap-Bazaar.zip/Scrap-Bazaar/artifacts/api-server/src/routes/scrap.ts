import { Router, type IRouter } from "express";
import { and, asc, count, desc, eq, ilike, or } from "drizzle-orm";
import { db, categoriesTable, scrapItemsTable } from "@workspace/db";
import {
  CreateCategoryBody,
  CreateCategoryResponse,
  CreateScrapItemBody,
  CreateScrapItemResponse,
  DeleteScrapItemParams,
  GetScrapItemParams,
  GetScrapItemResponse,
  ListCategoriesResponse,
  ListScrapItemsQueryParams,
  ListScrapItemsResponse,
  UpdateScrapItemBody,
  UpdateScrapItemParams,
  UpdateScrapItemResponse,
} from "@workspace/api-zod";
import { ensureSeedData, findCategoryId } from "../lib/seed";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

async function findItem(id: number) {
  const [item] = await db
    .select({
      id: scrapItemsTable.id,
      name: scrapItemsTable.name,
      category: categoriesTable.name,
      description: scrapItemsTable.description,
      pricePerKg: scrapItemsTable.pricePerKg,
      stockKg: scrapItemsTable.stockKg,
      imageUrl: scrapItemsTable.imageUrl,
      status: scrapItemsTable.status,
      createdAt: scrapItemsTable.createdAt,
    })
    .from(scrapItemsTable)
    .innerJoin(categoriesTable, eq(scrapItemsTable.categoryId, categoriesTable.id))
    .where(eq(scrapItemsTable.id, id));
  return item;
}

router.get("/categories", async (_req, res): Promise<void> => {
  await ensureSeedData();
  const rows = await db
    .select({
      id: categoriesTable.id,
      name: categoriesTable.name,
      itemCount: count(scrapItemsTable.id),
    })
    .from(categoriesTable)
    .leftJoin(scrapItemsTable, eq(scrapItemsTable.categoryId, categoriesTable.id))
    .groupBy(categoriesTable.id, categoriesTable.name)
    .orderBy(asc(categoriesTable.name));

  res.json(
    ListCategoriesResponse.parse(
      rows.map((row) => ({ ...row, itemCount: Number(row.itemCount) })),
    ),
  );
});

router.post("/categories", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [category] = await db
    .insert(categoriesTable)
    .values({ name: parsed.data.name.trim() })
    .returning();

  res.status(201).json(
    CreateCategoryResponse.parse({ ...category, itemCount: 0 }),
  );
});

router.get("/scrap-items", async (req, res): Promise<void> => {
  await ensureSeedData();
  const parsed = ListScrapItemsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const conditions = [];
  if (parsed.data.status) conditions.push(eq(scrapItemsTable.status, parsed.data.status));
  if (parsed.data.category) conditions.push(eq(categoriesTable.name, parsed.data.category));
  if (parsed.data.search) {
    const pattern = `%${parsed.data.search}%`;
    conditions.push(
      or(
        ilike(scrapItemsTable.name, pattern),
        ilike(scrapItemsTable.description, pattern),
        ilike(categoriesTable.name, pattern),
      ),
    );
  }

  const rows = await db
    .select({
      id: scrapItemsTable.id,
      name: scrapItemsTable.name,
      category: categoriesTable.name,
      description: scrapItemsTable.description,
      pricePerKg: scrapItemsTable.pricePerKg,
      stockKg: scrapItemsTable.stockKg,
      imageUrl: scrapItemsTable.imageUrl,
      status: scrapItemsTable.status,
      createdAt: scrapItemsTable.createdAt,
    })
    .from(scrapItemsTable)
    .innerJoin(categoriesTable, eq(scrapItemsTable.categoryId, categoriesTable.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(scrapItemsTable.createdAt));

  res.json(ListScrapItemsResponse.parse(rows));
});

router.post("/scrap-items", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateScrapItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { category, ...itemData } = parsed.data;
  const categoryId = await findCategoryId(category.trim());
  const [created] = await db
    .insert(scrapItemsTable)
    .values({
      ...itemData,
      categoryId,
    })
    .returning({ id: scrapItemsTable.id });

  const item = await findItem(created.id);
  res.status(201).json(CreateScrapItemResponse.parse(item));
});

router.get("/scrap-items/:id", async (req, res): Promise<void> => {
  const params = GetScrapItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const item = await findItem(params.data.id);
  if (!item) {
    res.status(404).json({ error: "Scrap item not found" });
    return;
  }

  res.json(GetScrapItemResponse.parse(item));
});

router.patch("/scrap-items/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateScrapItemParams.safeParse(req.params);
  const parsed = UpdateScrapItemBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { category, ...rest } = parsed.data;
  const updates = {
    ...rest,
    ...(category ? { categoryId: await findCategoryId(category.trim()) } : {}),
  };
  const [updated] = await db
    .update(scrapItemsTable)
    .set(updates)
    .where(eq(scrapItemsTable.id, params.data.id))
    .returning({ id: scrapItemsTable.id });

  if (!updated) {
    res.status(404).json({ error: "Scrap item not found" });
    return;
  }

  const item = await findItem(updated.id);
  res.json(UpdateScrapItemResponse.parse(item));
});

router.delete("/scrap-items/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteScrapItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(scrapItemsTable)
    .where(eq(scrapItemsTable.id, params.data.id))
    .returning({ id: scrapItemsTable.id });

  if (!deleted) {
    res.status(404).json({ error: "Scrap item not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;