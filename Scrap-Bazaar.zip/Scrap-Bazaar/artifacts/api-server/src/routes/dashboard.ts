import { Router, type IRouter } from "express";
import { and, count, eq, inArray, sum } from "drizzle-orm";
import { db, ordersTable, scrapItemsTable } from "@workspace/db";
import { GetDashboardSummaryResponse } from "@workspace/api-zod";
import { ensureSeedData } from "../lib/seed";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/dashboard/summary", requireAuth, async (_req, res): Promise<void> => {
  await ensureSeedData();
  const [totalItems] = await db
    .select({ value: count(scrapItemsTable.id) })
    .from(scrapItemsTable);
  const [activeItems] = await db
    .select({ value: count(scrapItemsTable.id) })
    .from(scrapItemsTable)
    .where(eq(scrapItemsTable.status, "active"));
  const [stock] = await db
    .select({ value: sum(scrapItemsTable.stockKg) })
    .from(scrapItemsTable)
    .where(eq(scrapItemsTable.status, "active"));
  const [pendingOrders] = await db
    .select({ value: count(ordersTable.id) })
    .from(ordersTable)
    .where(eq(ordersTable.status, "pending"));
  const [sales] = await db
    .select({ value: sum(ordersTable.total) })
    .from(ordersTable)
    .where(inArray(ordersTable.status, ["confirmed", "completed"]));

  res.json(
    GetDashboardSummaryResponse.parse({
      totalItems: Number(totalItems.value),
      activeItems: Number(activeItems.value),
      totalStockKg: Number(stock.value ?? 0),
      pendingOrders: Number(pendingOrders.value),
      totalSales: Number(sales.value ?? 0),
    }),
  );
});

export default router;