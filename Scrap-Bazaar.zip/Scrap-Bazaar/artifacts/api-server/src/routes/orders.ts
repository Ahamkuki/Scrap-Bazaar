import { Router, type IRouter } from "express";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db, orderItemsTable, ordersTable, scrapItemsTable } from "@workspace/db";
import {
  CreateOrderBody,
  CreateOrderResponse,
  ListOrdersResponse,
} from "@workspace/api-zod";
import { ensureSeedData } from "../lib/seed";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

async function getOrderWithItems(id: number) {
  const [order] = await db
    .select()
    .from(ordersTable)
    .where(eq(ordersTable.id, id));
  if (!order) return undefined;

  const items = await db
    .select({
      scrapItemId: orderItemsTable.scrapItemId,
      itemName: orderItemsTable.itemName,
      quantityKg: orderItemsTable.quantityKg,
      pricePerKg: orderItemsTable.pricePerKg,
      lineTotal: orderItemsTable.lineTotal,
    })
    .from(orderItemsTable)
    .where(eq(orderItemsTable.orderId, id));

  return { ...order, items };
}

router.get("/orders", requireAuth, async (_req, res): Promise<void> => {
  await ensureSeedData();
  const orders = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.createdAt));
  const items = await db.select().from(orderItemsTable);
  const byOrder = new Map<number, typeof items>();
  for (const item of items) {
    const existing = byOrder.get(item.orderId) ?? [];
    existing.push(item);
    byOrder.set(item.orderId, existing);
  }

  res.json(
    ListOrdersResponse.parse(
      orders.map((order) => ({
        ...order,
        items: (byOrder.get(order.id) ?? []).map((item) => ({
          scrapItemId: item.scrapItemId,
          itemName: item.itemName,
          quantityKg: item.quantityKg,
          pricePerKg: item.pricePerKg,
          lineTotal: item.lineTotal,
        })),
      })),
    ),
  );
});

router.post("/orders", async (req, res): Promise<void> => {
  await ensureSeedData();
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const itemIds = parsed.data.items.map((item) => item.scrapItemId);
  const inventory = await db
    .select()
    .from(scrapItemsTable)
    .where(inArray(scrapItemsTable.id, itemIds));
  const inventoryById = new Map(inventory.map((item) => [item.id, item]));

  for (const requested of parsed.data.items) {
    const item = inventoryById.get(requested.scrapItemId);
    if (!item || item.status !== "active") {
      res.status(400).json({ error: "One or more scrap items are no longer available" });
      return;
    }
    if (item.stockKg < requested.quantityKg) {
      res.status(400).json({ error: `${item.name} has only ${item.stockKg} kg available` });
      return;
    }
  }

  const lineItems = parsed.data.items.map((requested) => {
    const item = inventoryById.get(requested.scrapItemId)!;
    const lineTotal = Number((item.pricePerKg * requested.quantityKg).toFixed(2));
    return {
      scrapItemId: item.id,
      itemName: item.name,
      quantityKg: requested.quantityKg,
      pricePerKg: item.pricePerKg,
      lineTotal,
    };
  });
  const total = Number(
    lineItems.reduce((sum, item) => sum + item.lineTotal, 0).toFixed(2),
  );

  const order = await db.transaction(async (tx) => {
    const [createdOrder] = await tx
      .insert(ordersTable)
      .values({
        customerName: parsed.data.customerName.trim(),
        phone: parsed.data.phone.trim(),
        address: parsed.data.address.trim(),
        total,
        status: "pending",
      })
      .returning();

    await tx.insert(orderItemsTable).values(
      lineItems.map((item) => ({ ...item, orderId: createdOrder.id })),
    );

    for (const item of parsed.data.items) {
      await tx
        .update(scrapItemsTable)
        .set({
          stockKg: sql`${scrapItemsTable.stockKg} - ${item.quantityKg}`,
        })
        .where(eq(scrapItemsTable.id, item.scrapItemId));
    }

    return createdOrder;
  });

  const response = await getOrderWithItems(order.id);
  res.status(201).json(CreateOrderResponse.parse(response));
});

export default router;