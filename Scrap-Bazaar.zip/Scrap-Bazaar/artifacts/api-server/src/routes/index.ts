import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scrapRouter from "./scrap";
import ordersRouter from "./orders";
import dashboardRouter from "./dashboard";
import sellRequestsRouter from "./sell-requests";

const router: IRouter = Router();

router.use(healthRouter);
router.use(scrapRouter);
router.use(ordersRouter);
router.use(dashboardRouter);
router.use(sellRequestsRouter);

export default router;
