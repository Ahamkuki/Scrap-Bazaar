---
name: Generated client DOM iterable support
description: Generated React API client code uses Headers.entries and requires iterable DOM typings in its composite TypeScript project.
---

Add `dom.iterable` to the API client library TypeScript `lib` list when generated code uses `Headers.entries`; otherwise codegen succeeds but the chained library typecheck fails.

**Why:** The generated fetch helper relies on iterable `Headers`, while the default DOM typings do not expose `entries()`.

**How to apply:** If codegen reports `Property 'entries' does not exist on type 'Headers'`, inspect the API client tsconfig before changing generated output.