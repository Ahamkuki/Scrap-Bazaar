---
name: Seed initialization concurrency
description: First-load seed data must be guarded against concurrent API requests.
---

Guard one-time database seeding behind a shared promise, not only a boolean flag.

**Why:** Storefront, category, and dashboard queries can arrive together; a boolean-only guard lets concurrent requests attempt the same unique inserts.

**How to apply:** Keep the in-flight seed promise reusable until initialization completes, and clear it when initialization fails so a later request can retry.